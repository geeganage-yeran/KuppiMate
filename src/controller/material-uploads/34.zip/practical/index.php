<!DOCTYPE html>
<html>
    <head>
        <title>Product Order Form</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <h1>Product Order Form</h1>
        <form action="processOrder.php" method="post" >
            <label>Product Name:</label>
            <input type="text" name="pName" ><br>

            <label>Quantity:</label>
            <input type="number" name="quantity"  min="1"><br>

            <label>Shipping Address:</label><br>
            <textarea rows="4" cols="50" name="address" ></textarea><br>

            <label>Preferred Delivery Days:</label><br>
            <input type="checkbox" name="days[]" value="monday" id="monday">
            <label for="monday">Monday</label><br>

            <input type="checkbox" name="days[]" value="wedensday" id="wednesday">
            <label for="wednesday">Wednesday</label><br>

            <input type="checkbox" name="days[]" value="friday" id="friday">
            <label for="friday">Friday</label><br>

            <label>Payment Method:</label><br>
            <input type="radio" name="payment" value="credit_card" id="credit_card">
            <label for="credit_card">Credit Card</label><br>

            <input type="radio" name="payment" value="paypal" id="paypal">
            <label for="paypal">PayPal</label><br>

            <input type="radio" name="payment" value="bank_transfer" id="bank_transfer">
            <label for="bank_transfer">Bank Transfer</label><br>
            <div class="center-button">
                <input type="submit" value="Place Order">
            </div>
            <?php
                if($_SERVER["REQUEST_METHOD"]=="GET"){
                    if(isset($_GET['id']) && !empty($_GET['id']) ){
                        if($_GET["id"]=="101"){
                            echo "<h6 style='color:green;' >Your order has been saved successfully.</h6>";
                        }elseif($_GET["id"]=="102"){
                            echo "<h6 style='color:red;' >An error occurred. Please try again</h6>";
                        }elseif($_GET["id"]=="103"){
                            echo "<h6 style='color:red;' >Fill out the all Fields</h6>";
                        } 
                    }
                }
            ?>
        </form>
    </body>
</html>
