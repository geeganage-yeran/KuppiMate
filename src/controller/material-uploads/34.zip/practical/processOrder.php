<?php

include_once './DbConnector.php';
include_once './Order.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['pName'], $_POST['quantity'], $_POST['address'], $_POST['days'], $_POST['payment'])) {
        if (!empty($_POST['pName']) && !empty($_POST['quantity']) && !empty($_POST['address']) && !empty($_POST['days']) && !empty($_POST['payment'])) {

            $product_name = filter_var(trim($_POST["pName"]), FILTER_SANITIZE_STRING);
            $quantity = $_POST["quantity"];
            $shipping_address = filter_var($_POST["address"],FILTER_SANITIZE_STRING);
            $delivery_days = implode(",", $_POST['days']);
            $payment_method = $_POST["payment"];

            $con = new DbConnector();
            $order = new Order($product_name, $quantity, $shipping_address, $delivery_days, $payment_method);
            if ($order->save($con->getConection())) {
                header("Location:index.php?id=101");
                exit();
            } else {
                header("Location:index.php?id=102");
                exit();
            }
        } else {
            header("Location:index.php?id=103");
            exit();
        }
    }
}

