<?php

class DbConnector {
    private $host="localhost";
    private $dbname="my_shop";
    private $dpuser="cst_user";
    private $dbpw="password";
    
    public function getConection() {
        $dsn="mysql:host=".$this->host.";dbname=".$this->dbname;
        try {
            $con=new PDO($dsn, $this->dpuser,$this->dbpw);
            return $con;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }       
        
    }
}
