<?php

class Order {
    private $order_id;
    private $product_name;
    private $quantity;
    private $shipping_address;
    private $delivery_days=[];
    private $payment_method;
    
    function __construct($product_name, $quantity, $shipping_address, $delivery_days, $payment_method) {
        $this->product_name = $product_name;
        $this->quantity = $quantity;
        $this->shipping_address = $shipping_address;
        $this->delivery_days = $delivery_days;
        $this->payment_method = $payment_method;
    }
    
    public function save($con) {
        try {
            $query="INSERT INTO orders(product_name,quantity,shipping_address,delivery_days,payment_method) VALUES (?,?,?,?,?)";
            $stmt=$con->prepare($query);
            $stmt->bindParam(1,$this->product_name);
            $stmt->bindParam(2,$this->quantity);
            $stmt->bindParam(3,$this->shipping_address);
            $stmt->bindParam(4,$this->delivery_days);
            $stmt->bindParam(5,$this->payment_method);
            $stmt->execute();
            return $stmt->rowCount()>0;
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
    
    

    
    
}
